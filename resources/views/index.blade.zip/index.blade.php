<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Keren</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Swiper JS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js"></script>
</head>
<body class="bg-gray-50">
    <!-- Header/Navbar -->
    <nav class="bg-green-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold">Logo Website</h1>
                <div class="hidden md:flex space-x-6">
                    <a href="#" class="hover:text-green-200">Beranda</a>
                    <a href="#" class="hover:text-green-200">Galeri</a>
                    <a href="#" class="hover:text-green-200">Agenda</a>
                    <a href="#" class="hover:text-green-200">Kontak</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Slider -->
    <div class="swiper hero-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide h-[500px]">
                <img src="{{ asset('img/gambar1.png') }}" alt="Slide 1" class="w-full h-full object-cover">
            </div>
            <div class="swiper-slide h-[500px]">
                <img src="{{ asset('img/gambar2.png') }}" alt="Slide 2" class="w-full h-full object-cover">
            </div>
            <div class="swiper-slide h-[500px]">
                <img src="{{ asset('img/gambar3.png') }}" alt="Slide 3" class="w-full h-full object-cover">
            </div>
        </div>
        <div class="swiper-pagination"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>

    <!-- Konten Utama -->
    <div class="container mx-auto px-4 py-8">
        <!-- Berita Terbaru -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6 text-green-800">Berita Terbaru</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Kartu Berita -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Berita 1" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="font-bold text-xl mb-2 text-green-700">Judul Berita 1</h3>
                        <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">Baca Selengkapnya</a>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Berita 1" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="font-bold text-xl mb-2 text-green-700">Judul Berita 1</h3>
                        <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">Baca Selengkapnya</a>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Berita 1" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="font-bold text-xl mb-2 text-green-700">Judul Berita 1</h3>
                        <p class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">Baca Selengkapnya</a>
                    </div>
                </div>
               
                <!-- Ulangi untuk berita lainnya -->
            </div>
        </section>

        <!-- Galeri Foto -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6 text-green-800">Galeri Foto</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="relative group">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Galeri 1" class="w-full h-64 object-cover rounded-lg">
                    <div class="absolute inset-0 bg-green-600 bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                        <span class="text-white text-lg font-bold">Lihat Foto</span>
                    </div>
                </div>
                <!-- Ulangi untuk foto lainnya -->
                <div class="relative group">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Galeri 1" class="w-full h-64 object-cover rounded-lg">
                    <div class="absolute inset-0 bg-green-600 bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                        <span class="text-white text-lg font-bold">Lihat Foto</span>
                    </div>
                </div>
                <div class="relative group">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Galeri 1" class="w-full h-64 object-cover rounded-lg">
                    <div class="absolute inset-0 bg-green-600 bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                        <span class="text-white text-lg font-bold">Lihat Foto</span>
                    </div>
                </div>
                <div class="relative group">
                    <img src="{{ asset('img/gambar4.png') }}" alt="Galeri 1" class="w-full h-64 object-cover rounded-lg">
                    <div class="absolute inset-0 bg-green-600 bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                        <span class="text-white text-lg font-bold">Lihat Foto</span>
                    </div>
                </div>
               
            </div>
        </section>

        <!-- Galeri Video -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6 text-green-800">Galeri Video</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <div class="aspect-w-16 aspect-h-9">
                        <img src="{{ asset('img/gambar4.png') }}" alt="Video Thumbnail" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold text-lg text-green-700">Judul Video 1</h3>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <div class="aspect-w-16 aspect-h-9">
                        <img src="{{ asset('img/gambar4.png') }}" alt="Video Thumbnail" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold text-lg text-green-700">Judul Video 1</h3>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-green-100">
                    <div class="aspect-w-16 aspect-h-9">
                        <img src="{{ asset('img/gambar4.png') }}" alt="Video Thumbnail" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold text-lg text-green-700">Judul Video 1</h3>
                    </div>
                </div>
                <!-- Ulangi untuk video lainnya -->
            </div>
        </section>

        <!-- Agenda -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6 text-green-800">Agenda Mendatang</h2>
            <div class="space-y-4">
                <div class="bg-white rounded-lg shadow-md p-4 border border-green-100">
                    <div class="flex items-center">
                        <div class="bg-green-600 text-white rounded-lg p-3 text-center min-w-[80px]">
                            <span class="block text-2xl font-bold">15</span>
                            <span class="block text-sm">Nov</span>
                        </div>
                        <div class="ml-4">
                            <h3 class="font-bold text-xl text-green-700">Judul Agenda</h3>
                            <p class="text-gray-600">Lokasi: Gedung Serbaguna</p>
                            <p class="text-gray-600">Waktu: 09.00 - 12.00 WIB</p>
                        </div>

                        <div class="bg-green-600 text-white rounded-lg p-3 text-center min-w-[80px]">
                            <span class="block text-2xl font-bold">15</span>
                            <span class="block text-sm">Nov</span>
                        </div>
                        <div class="ml-4">
                            <h3 class="font-bold text-xl text-green-700">Judul Agenda</h3>
                            <p class="text-gray-600">Lokasi: Gedung Serbaguna</p>
                            <p class="text-gray-600">Waktu: 09.00 - 12.00 WIB</p>
                        </div>

                        <div class="bg-green-600 text-white rounded-lg p-3 text-center min-w-[80px]">
                            <span class="block text-2xl font-bold">15</span>
                            <span class="block text-sm">Nov</span>
                        </div>
                        <div class="ml-4">
                            <h3 class="font-bold text-xl text-green-700">Judul Agenda</h3>
                            <p class="text-gray-600">Lokasi: Gedung Serbaguna</p>
                            <p class="text-gray-600">Waktu: 09.00 - 12.00 WIB</p>
                        </div>

                        <div class="bg-green-600 text-white rounded-lg p-3 text-center min-w-[80px]">
                            <span class="block text-2xl font-bold">15</span>
                            <span class="block text-sm">Nov</span>
                        </div>
                        <div class="ml-4">
                            <h3 class="font-bold text-xl text-green-700">Judul Agenda</h3>
                            <p class="text-gray-600">Lokasi: Gedung Serbaguna</p>
                            <p class="text-gray-600">Waktu: 09.00 - 12.00 WIB</p>
                        </div>

                        <div class="bg-green-600 text-white rounded-lg p-3 text-center min-w-[80px]">
                            <span class="block text-2xl font-bold">15</span>
                            <span class="block text-sm">Nov</span>
                        </div>
                        <div class="ml-4">
                            <h3 class="font-bold text-xl text-green-700">Judul Agenda</h3>
                            <p class="text-gray-600">Lokasi: Gedung Serbaguna</p>
                            <p class="text-gray-600">Waktu: 09.00 - 12.00 WIB</p>
                        </div>
                        
                    </div>
                </div>
                <!-- Ulangi untuk agenda lainnya -->
            </div>
        </section>

        <!-- Link Penting -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6 text-green-800">Link Penting</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="#" class="flex items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-green-100">
                    <span class="text-lg font-semibold text-green-600">Website 1</span>
                </a>
                <a href="#" class="flex items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-green-100">
                    <span class="text-lg font-semibold text-green-600">Website 1</span>
                </a>
                <a href="#" class="flex items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-green-100">
                    <span class="text-lg font-semibold text-green-600">Website 1</span>
                </a>
                <a href="#" class="flex items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-green-100">
                    <span class="text-lg font-semibold text-green-600">Website 1</span>
                </a>
                
                <!-- Ulangi untuk link lainnya -->
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="bg-green-800 text-white py-8">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">Tentang Kami</h3>
                    <p class="text-green-200">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
                <div>
                    <h3 class="text-xl font-bold mb-4">Kontak</h3>
                    <p class="text-green-200">Email: info@website.com</p>
                    <p class="text-green-200">Telepon: (021) 1234-5678</p>
                    <p class="text-green-200">Alamat: Jalan Contoh No. 123</p>
                </div>
                <div>
                    <h3 class="text-xl font-bold mb-4">Ikuti Kami</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-green-200 hover:text-white transition-colors">Facebook</a>
                        <a href="#" class="text-green-200 hover:text-white transition-colors">Twitter</a>
                        <a href="#" class="text-green-200 hover:text-white transition-colors">Instagram</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script>
        // Inisialisasi Swiper untuk hero slider
        new Swiper('.hero-slider', {
            slidesPerView: 1,
            loop: true,
            autoplay: {
                delay: 5000,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    </script>
</body>
</html>